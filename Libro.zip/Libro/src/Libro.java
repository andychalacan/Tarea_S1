
public class Libro {
        String titulo,autor;
        int PaginaCount;

        public Libro(String titulo, String autor, int PaginaCount){
            this.titulo= titulo;
            this.autor=autor;
            this.PaginaCount=PaginaCount;
        }

        public  static void infoLibro(String titulo,String autor, int PaginaCount){
            System.out.println("Titulo: "+titulo+", Autor: "+autor+", Paginas: "+PaginaCount);
        }
        public static void main(String[] args){
            Libro novela = new Libro("Plaga de Rosas Negras","Brick Satori",28);
            Libro.infoLibro(novela.titulo,novela.autor,novela.PaginaCount);
        }
    }

