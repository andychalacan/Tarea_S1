
public class Persona {
    String nombre,genero;
    int edad;

    public Persona(String nombre,String genero, int edad){
        this.nombre=nombre;
        this.genero=genero;
        this.edad=edad;
    }

    public  static void saludo(String nombre,String genero, int edad){
        System.out.println("Hola me llamo "+nombre+" de genero "+genero+" y tengo "+edad+" años");
    }
    public static void main(String[] args){
        Persona estudiante = new Persona("andy","masculino",21);
        Persona.saludo(estudiante.nombre, estudiante.genero, estudiante.edad);
    }
}
